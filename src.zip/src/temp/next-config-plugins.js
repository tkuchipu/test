exports.componentPropsPlugin = require('../lib/next-config/plugins/component-props');
exports.corsHeaderPlugin = require('../lib/next-config/plugins/cors-header');
