export { graphqlSitemapServicePlugin } from 'src/lib/sitemap-fetcher/plugins/graphql-sitemap-service';
