export { defaultPlugin } from 'src/lib/site-resolver/plugins/default';
