import { JSX } from 'react';

const Scripts = (): JSX.Element | null => {
  return null;
};

export default Scripts;
