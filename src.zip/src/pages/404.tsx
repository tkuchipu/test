import { JSX } from 'react';
import NotFound from 'src/NotFound';

const Custom404 = (): JSX.Element => <NotFound />;

export default Custom404;
