'use client';
import { JSX, useState } from 'react';

interface FieldModel {
  title: string;
  required: boolean;
  model: any;
  valueField: { name: string; id: string; value: string | null };
  fieldIdField: { name: string; id: string; value: string };
  buttonField: { name: string; id: string; value: string | null };
}

interface AntiForgeryToken {
  name: string;
  value: string;
}

interface FormFields {
  antiForgeryToken: AntiForgeryToken;
  formSessionId: { name: string; value: string };
  formItemId: { name: string; value: string };
  pageItemId: { name: string; value: string };
  fields: Array<{
    fields: FieldModel[];
  }>;
}

interface FormProps {
  fields: FormFields;
}

const Form = ({  }: FormProps): JSX.Element => {
  const [form, setForm] = useState({ name: "", email: "" });

  return (
    <div className="max-w-md mx-auto mt-10 p-4 border rounded-xl">
      <h1 className="text-xl font-bold mb-4">Basic Form</h1>
      <form className="flex flex-col gap-3">
        <input
          type="text"
          placeholder="Your Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="border p-2 rounded"
          required
        />
        <input
          type="email"
          placeholder="Your Email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="border p-2 rounded"
          required
        />
        <button type="submit" className="bg-blue-600 text-white py-2 rounded">
          Submit
        </button>
      </form>
    </div>
  );
};

export default Form;
